package com.example.ompitchtrainer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var pitchView: PitchGraphView
    private lateinit var hzText: TextView
    private lateinit var deviationText: TextView
    private lateinit var scoreText: TextView
    private lateinit var statusText: TextView
    private lateinit var targetInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var playToneButton: Button
    private lateinit var resetButton: Button
    private lateinit var sessionText: TextView

    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    private var targetHz = 136.0
    private var sessionSeconds = 0

    private val sampleRate = 44100
    private val windowSize = 4096
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pitchHistory = ArrayDeque<Float>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 246, 252)
        window.navigationBarColor = Color.rgb(248, 246, 252)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        } else {
            statusText.text = "Microphone ready"
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(248, 246, 252))
            isFillViewport = true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(24), d(20), d(28))
        }

        root.addView(TextView(this).apply {
            text = "🕉  Om Pitch Trainer"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(45, 31, 62))
        }, lp())

        root.addView(TextView(this).apply {
            text = "Train your pitch • Track your chanting consistency"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(105, 95, 112))
            setPadding(0, d(4), 0, d(18))
        }, lp())

        val modeLabel = label("CHANTING MODE")
        root.addView(modeLabel, lp())

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val omButton = optionButton("ॐ")
        val shivayaButton = optionButton("ॐ नमः शिवाय")
        modeRow.addView(omButton, weightLp())
        modeRow.addView(shivayaButton, weightLp())
        root.addView(modeRow, lp())

        root.addView(label("TARGET PITCH (Hz)"), lp(-1, 40))

        val targetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val minus = button("−", 52)
        val plus = button("+", 52)

        targetInput = EditText(this).apply {
            setText("136")
            textSize = 22f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(Color.rgb(45, 31, 62))
            setSingleLine(true)
            background = rounded(Color.WHITE, Color.rgb(126, 92, 164), 2)
        }
        targetRow.addView(minus, LinearLayout.LayoutParams(d(52), d(54)))
        targetRow.addView(targetInput, LinearLayout.LayoutParams(d(130), d(54)).apply {
            leftMargin = d(12); rightMargin = d(12)
        })
        targetRow.addView(plus, LinearLayout.LayoutParams(d(52), d(54)))
        root.addView(targetRow, lp())

        minus.setOnClickListener { changeTarget(-1) }
        plus.setOnClickListener { changeTarget(1) }

        val toneRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }
        playToneButton = button("▶  Play reference tone", 0).apply {
            setOnClickListener { playReferenceTone() }
        }
        resetButton = button("↺  Reset", 0).apply {
            setOnClickListener { resetSession() }
        }
        toneRow.addView(playToneButton, weightLp())
        toneRow.addView(resetButton, weightLp())
        root.addView(toneRow, lp(-1, 58))

        val targetInfo = centered("Target: 136 Hz • Keep your voice close to the line")
        root.addView(targetInfo, lp())

        hzText = bigText("— Hz")
        root.addView(hzText, lp(-1, 66))

        deviationText = centered("Waiting for voice…")
        root.addView(deviationText, lp())

        pitchView = PitchGraphView(this)
        root.addView(pitchView, LinearLayout.LayoutParams(-1, d(260)).apply {
            topMargin = d(8); bottomMargin = d(10)
        })

        scoreText = bigText("Consistency: —").apply { textSize = 27f }
        root.addView(scoreText, lp())

        sessionText = centered("Session: 00:00")
        root.addView(sessionText, lp())

        statusText = centered("Microphone ready")
        root.addView(statusText, lp())

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, d(10), 0, d(6))
        }

        startButton = actionButton("▶  START CHANTING").apply {
            setOnClickListener { startListening() }
        }
        stopButton = actionButton("■  STOP").apply {
            isEnabled = false
            alpha = 0.55f
            setOnClickListener { stopListening() }
        }

        controls.addView(startButton, weightLp())
        controls.addView(stopButton, weightLp())
        root.addView(controls, lp())

        root.addView(TextView(this).apply {
            text = "Tip: keep the phone 20–40 cm away. A quiet room gives better pitch detection. The consistency score is a training metric, not a claim that one Hz value is universally correct."
            textSize = 12f
            setTextColor(Color.rgb(90, 82, 96))
            setPadding(d(4), d(10), d(4), d(4))
        }, lp())

        omButton.setOnClickListener {
            targetInput.setText("136")
            targetInfo.text = "ॐ mode • Target: 136 Hz"
        }
        shivayaButton.setOnClickListener {
            targetInput.setText("136")
            targetInfo.text = "ॐ नमः शिवाय mode • Target: 136 Hz"
        }

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(Color.rgb(100, 87, 110))
        setPadding(d(2), d(8), d(2), d(5))
    }

    private fun centered(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Color.rgb(82, 73, 90))
    }

    private fun bigText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 36f
        gravity = Gravity.CENTER
        setTextColor(Color.rgb(74, 46, 117))
    }

    private fun button(text: String, width: Int) = Button(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.rgb(65, 44, 82))
        background = rounded(Color.WHITE, Color.rgb(126, 92, 164), 1)
        if (width > 0) minimumWidth = d(width)
    }

    private fun optionButton(text: String) = button(text, 0).apply { minimumHeight = d(52); setPadding(d(8), 0, d(8), 0) }

    private fun actionButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(74, 46, 117), Color.rgb(74, 46, 117), 1)
        isAllCaps = false
        minimumHeight = d(56)
    }

    private fun rounded(fill: Int, stroke: Int, strokeWidth: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(fill)
            setStroke(strokeWidth, stroke)
            cornerRadius = 18f
        }

    private fun d(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun lp(width: Int = -1, height: Int = -2) = LinearLayout.LayoutParams(
        if (width < 0) width else d(width),
        if (height < 0) height else d(height)
    )

    private fun weightLp() = LinearLayout.LayoutParams(0, d(52), 1f).apply {
        leftMargin = d(5); rightMargin = d(5)
    }

    private fun changeTarget(delta: Int) {
        val current = targetInput.text.toString().toDoubleOrNull() ?: 136.0
        val next = (current + delta).coerceIn(60.0, 400.0)
        targetInput.setText(String.format("%.0f", next))
    }

    private fun resetSession() {
        stopListening()
        pitchHistory.clear()
        pitchView.clear()
        hzText.text = "— Hz"
        deviationText.text = "Waiting for voice…"
        scoreText.text = "Consistency: —"
        sessionSeconds = 0
        sessionText.text = "Session: 00:00"
        statusText.text = "Ready • Set your target and tap Start"
    }

    private fun playReferenceTone() {
        val hz = targetInput.text.toString().toDoubleOrNull()?.coerceIn(60.0, 400.0) ?: 136.0
        Thread {
            try {
                val durationMs = 1200
                val count = sampleRate * durationMs / 1000
                val samples = ShortArray(count)
                for (i in samples.indices) {
                    val envelope = if (i < sampleRate * 0.05) i.toDouble() / (sampleRate * 0.05)
                    else if (i > count - sampleRate * 0.1) (count - i).toDouble() / (sampleRate * 0.1)
                    else 1.0
                    samples[i] = (sin(2.0 * Math.PI * hz * i / sampleRate) * 8000 * envelope).toInt().toShort()
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .build()
                track.play()
                track.write(samples, 0, samples.size)
                track.stop()
                track.release()
            } catch (_: Throwable) {}
        }.start()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        targetHz = targetInput.text.toString().toDoubleOrNull() ?: 136.0
        if (targetHz !in 60.0..400.0) {
            Toast.makeText(this, "Target must be between 60 and 400 Hz", Toast.LENGTH_SHORT).show()
            return
        }

        pitchHistory.clear()
        pitchView.clear()
        sessionSeconds = 0
        running = true

        startButton.isEnabled = false
        startButton.alpha = 0.55f
        stopButton.isEnabled = true
        stopButton.alpha = 1f
        targetInput.isEnabled = false
        playToneButton.isEnabled = false
        statusText.text = "🎤 Listening… chant ॐ"

        mainHandler.post(timerRunnable)

        worker = Thread {
            try {
                val minBuffer = AudioRecord.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBuffer <= 0) throw IllegalStateException("Microphone is unavailable")

                recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    max(minBuffer * 2, windowSize * 2)
                )

                if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("Could not initialize microphone")
                }

                recorder?.startRecording()
                val buffer = ShortArray(windowSize)

                while (running) {
                    val n = recorder?.read(buffer, 0, buffer.size) ?: 0
                    if (n > 2048) {
                        val result = PitchDetector.detect(buffer, n, sampleRate)
                        if (result != null) {
                            mainHandler.post {
                                if (running) updatePitch(result.pitchHz, result.confidence)
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                mainHandler.post {
                    statusText.text = "Microphone error: ${t.message ?: "unknown error"}"
                    stopListening()
                }
            }
        }.also { it.start() }
    }

    private val timerRunnable = object : Runnable {
        override fun run() {
            if (running) {
                sessionSeconds++
                sessionText.text = String.format("Session: %02d:%02d", sessionSeconds / 60, sessionSeconds % 60)
                mainHandler.postDelayed(this, 1000)
            }
        }
    }

    private fun updatePitch(hz: Double, confidence: Double) {
        if (hz !in 60.0..400.0 || confidence < 0.55) return

        pitchHistory.addLast(hz.toFloat())
        while (pitchHistory.size > 80) pitchHistory.removeFirst()

        hzText.text = String.format("%.1f Hz", hz)

        val cents = 1200.0 * log2(hz / targetHz)
        val percent = abs(hz - targetHz) / targetHz * 100.0
        deviationText.text = String.format("Deviation: %+.1f cents  •  %.2f%%", cents, percent)
        pitchView.addPitch(hz.toFloat(), targetHz.toFloat())

        val values = pitchHistory.toList()
        if (values.size >= 5) {
            val mean = values.average()
            val variance = values.map { (it - mean) * (it - mean) }.average()
            val sd = sqrt(variance)
            val stability = (100.0 - sd / targetHz * 500.0).coerceIn(0.0, 100.0)
            val accuracy = (100.0 - abs(mean - targetHz) / targetHz * 400.0).coerceIn(0.0, 100.0)
            val score = (stability * 0.6 + accuracy * 0.4).coerceIn(0.0, 100.0)

            scoreText.text = String.format("Consistency: %.0f%%", score)
            statusText.text = if (abs(cents) <= 30) "✓ Excellent — you are close to target"
            else if (abs(cents) <= 70) "≈ Almost there — adjust slightly"
            else "↑ Adjust your pitch toward the target"
        }
    }

    private fun stopListening() {
        running = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        worker = null
        startButton.isEnabled = true
        startButton.alpha = 1f
        stopButton.isEnabled = false
        stopButton.alpha = 0.55f
        targetInput.isEnabled = true
        playToneButton.isEnabled = true
        if (statusText.text.toString().startsWith("🎤")) {
            statusText.text = "Session stopped • Ready for another round"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            statusText.text = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                "Microphone ready" else "Microphone permission is required"
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}

data class PitchResult(val pitchHz: Double, val confidence: Double)

object PitchDetector {
    fun detect(samples: ShortArray, n: Int, sampleRate: Int): PitchResult? {
        var rms = 0.0
        for (i in 0 until n) {
            val x = samples[i] / 32768.0
            rms += x * x
        }
        rms = sqrt(rms / n)
        if (rms < 0.012) return null

        val minLag = sampleRate / 400
        val maxLag = sampleRate / 60
        val upper = maxLag.coerceAtMost(n - 2)

        var bestLag = -1
        var bestCorr = 0.0

        for (lag in minLag..upper) {
            var sum = 0.0
            var energy1 = 0.0
            var energy2 = 0.0
            val limit = n - lag

            for (i in 0 until limit) {
                val x = samples[i] / 32768.0
                val y = samples[i + lag] / 32768.0
                sum += x * y
                energy1 += x * x
                energy2 += y * y
            }

            val denom = sqrt(energy1 * energy2)
            if (denom > 0.0) {
                val corr = sum / denom
                if (corr > bestCorr) {
                    bestCorr = corr
                    bestLag = lag
                }
            }
        }

        if (bestLag <= 0 || bestCorr < 0.55) return null
        return PitchResult(sampleRate.toDouble() / bestLag, bestCorr)
    }
}

class PitchGraphView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val values = ArrayDeque<Float>()
    private var target = 136f

    fun addPitch(value: Float, targetHz: Float) {
        target = targetHz
        values.addLast(value)
        while (values.size > 80) values.removeFirst()
        invalidate()
    }

    fun clear() {
        values.clear()
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawRoundRect(0f, 0f, w, h, 22f, 22f, paint)

        val minHz = max(60f, target - 45f)
        val maxHz = target + 45f

        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.rgb(126, 92, 164)

        val targetY = h - ((target - minHz) / (maxHz - minHz)) * h
        canvas.drawLine(0f, targetY, w, targetY, paint)

        if (values.size < 2) return

        val list = values.toList()
        val path = android.graphics.Path()
        for (i in list.indices) {
            val x = i.toFloat() / (list.size - 1).coerceAtLeast(1) * w
            val normalized = ((list[i] - minHz) / (maxHz - minHz)).coerceIn(0f, 1f)
            val y = h - normalized * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        paint.color = Color.rgb(74, 46, 117)
        paint.strokeWidth = 5f
        canvas.drawPath(path, paint)
    }
}
