plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ompitchtrainer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ompitchtrainer"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "4.2.0"
    }
}

kotlin {
    jvmToolchain(17)
}
