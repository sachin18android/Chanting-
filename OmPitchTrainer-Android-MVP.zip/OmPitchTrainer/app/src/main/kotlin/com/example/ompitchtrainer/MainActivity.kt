package com.example.ompitchtrainer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var pitchView: PitchGraphView
    private lateinit var hzText: TextView
    private lateinit var deviationText: TextView
    private lateinit var scoreText: TextView
    private lateinit var statusText: TextView
    private lateinit var targetInput: EditText
    private lateinit var startButton: Button

    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var running = false

    private val sampleRate = 44100
    private val fftLikeWindow = 4096
    private val mainHandler = Handler(Looper.getMainLooper())

    private val pitchHistory = ArrayDeque<Float>()
    private var targetHz = 136.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        buildUi()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(0xFFF8F6FC.toInt())
        }

        val title = TextView(this).apply {
            text = "ॐ  Om Pitch Trainer"
            textSize = 28f
            setTextColor(0xFF241B2F.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Real-time pitch & chanting consistency"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF665E6E.toInt())
        }
        root.addView(subtitle, lp())

        val targetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 22, 0, 10)
        }

        targetRow.addView(TextView(this).apply {
            text = "Target pitch (Hz)"
            textSize = 16f
        }, LinearLayout.LayoutParams(0, 56, 1f))

        targetInput = EditText(this).apply {
            setText("136")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            gravity = Gravity.CENTER
            textSize = 18f
        }
        targetRow.addView(targetInput, LinearLayout.LayoutParams(130, 56))
        root.addView(targetRow)

        hzText = bigText("— Hz")
        root.addView(hzText, lp(0, 88))

        deviationText = centeredText("Waiting for voice…")
        root.addView(deviationText, lp())

        pitchView = PitchGraphView(this)
        root.addView(pitchView, LinearLayout.LayoutParams(-1, 250))

        scoreText = bigText("Consistency: —")
        root.addView(scoreText, lp(0, 72))

        statusText = centeredText("Tap Start and chant ॐ")
        root.addView(statusText, lp())

        startButton = Button(this).apply {
            text = "START CHANTING"
            setOnClickListener {
                if (running) stopListening() else startListening()
            }
        }
        root.addView(startButton, lp(0, 64))

        val note = TextView(this).apply {
            text = "Tip: use a quiet room and keep the phone 20–40 cm away. " +
                    "The app evaluates pitch consistency; it does not claim that one Hz value is universally “correct”."
            textSize = 12f
            setTextColor(0xFF6B6470.toInt())
            setPadding(0, 14, 0, 0)
        }
        root.addView(note, lp())

        setContentView(root)
    }

    private fun lp(width: Int = -1, height: Int = -2): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(width, height).apply { bottomMargin = 8 }

    private fun bigText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 36f
        gravity = Gravity.CENTER
        setTextColor(0xFF4A2E75.toInt())
    }

    private fun centeredText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(0xFF514958.toInt())
    }

    private fun startListening() {
        val parsed = targetInput.text.toString().toDoubleOrNull()
        if (parsed == null || parsed !in 60.0..400.0) {
            Toast.makeText(this, "Enter a target between 60 and 400 Hz", Toast.LENGTH_SHORT).show()
            return
        }
        targetHz = parsed
        pitchHistory.clear()
        pitchView.clear()
        running = true
        startButton.text = "STOP"
        statusText.text = "Listening… chant ॐ"
        worker = Thread {
            try {
                val minBuffer = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = max(minBuffer * 2, fftLikeWindow * 2)

                recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                recorder?.startRecording()

                val buffer = ShortArray(fftLikeWindow)

                while (running) {
                    val n = recorder?.read(buffer, 0, buffer.size) ?: 0
                    if (n > 2048) {
                        val result = PitchDetector.detect(buffer, n, sampleRate)
                        if (result != null) {
                            mainHandler.post {
                                updatePitch(result.pitchHz, result.confidence)
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                mainHandler.post {
                    statusText.text = "Microphone error: ${t.message ?: "unknown error"}"
                    stopListening()
                }
            }
        }.also { it.start() }
    }

    private fun updatePitch(hz: Double, confidence: Double) {
        if (hz < 60 || hz > 400 || confidence < 0.55) return

        pitchHistory.addLast(hz.toFloat())
        while (pitchHistory.size > 80) pitchHistory.removeFirst()

        hzText.text = String.format("%.1f Hz", hz)

        val cents = 1200.0 * log2(hz / targetHz)
        val percent = abs(hz - targetHz) / targetHz * 100.0
        deviationText.text = String.format(
            "Deviation: %+.1f cents  (%.2f%%)",
            cents, percent
        )

        pitchView.addPitch(hz.toFloat(), targetHz.toFloat())

        val values = pitchHistory.toList()
        if (values.size >= 5) {
            val mean = values.average()
            val variance = values.map { (it - mean) * (it - mean) }.average()
            val sd = sqrt(variance)
            val stability = (100.0 - (sd / max(targetHz, 1.0) * 100.0) * 5.0).coerceIn(0.0, 100.0)
            val accuracy = (100.0 - (abs(mean - targetHz) / targetHz * 100.0) * 4.0)
                .coerceIn(0.0, 100.0)
            val score = (stability * 0.6 + accuracy * 0.4).coerceIn(0.0, 100.0)
            scoreText.text = String.format("Consistency: %.0f%%", score)
            statusText.text = if (abs(cents) <= 30) "On target — keep the pitch steady" else "Adjust pitch toward the target"
        }
    }

    private fun stopListening() {
        running = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        worker = null
        startButton.text = "START CHANTING"
        if (statusText.text.toString().startsWith("Listening")) {
            statusText.text = "Session stopped"
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}

data class PitchResult(val pitchHz: Double, val confidence: Double)

object PitchDetector {
    // Simple normalized autocorrelation pitch detector.
    // Good enough for the MVP; production version should add stronger
    // noise rejection, harmonic correction and smoothing.
    fun detect(samples: ShortArray, n: Int, sampleRate: Int): PitchResult? {
        var rms = 0.0
        for (i in 0 until n) {
            val x = samples[i] / 32768.0
            rms += x * x
        }
        rms = sqrt(rms / n)
        if (rms < 0.012) return null

        val minLag = sampleRate / 400
        val maxLag = sampleRate / 60
        val upper = min(maxLag, n - 2)

        var bestLag = -1
        var bestCorr = 0.0

        for (lag in minLag..upper) {
            var sum = 0.0
            var energy1 = 0.0
            var energy2 = 0.0
            val limit = n - lag

            for (i in 0 until limit) {
                val x = samples[i] / 32768.0
                val y = samples[i + lag] / 32768.0
                sum += x * y
                energy1 += x * x
                energy2 += y * y
            }

            val denom = sqrt(energy1 * energy2)
            if (denom > 0.0) {
                val corr = sum / denom
                if (corr > bestCorr) {
                    bestCorr = corr
                    bestLag = lag
                }
            }
        }

        if (bestLag <= 0 || bestCorr < 0.55) return null

        // Parabolic interpolation around the selected lag improves resolution.
        // We keep the MVP simple and use the integer lag as the final estimate.
        val pitch = sampleRate.toDouble() / bestLag
        return PitchResult(pitch, bestCorr)
    }
}

class PitchGraphView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val values = ArrayDeque<Float>()
    private var target = 136f

    fun addPitch(value: Float, targetHz: Float) {
        target = targetHz
        values.addLast(value)
        while (values.size > 80) values.removeFirst()
        invalidate()
    }

    fun clear() {
        values.clear()
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawRoundRect(0f, 0f, w, h, 22f, 22f, paint)

        val minHz = max(60f, target - 45f)
        val maxHz = target + 45f

        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = 0xFF8E72B3.toInt()

        val targetY = h - ((target - minHz) / (maxHz - minHz)) * h
        canvas.drawLine(0f, targetY, w, targetY, paint)

        if (values.size < 2) return

        val list = values.toList()
        val path = android.graphics.Path()

        for (i in list.indices) {
            val x = if (list.size == 1) 0f else i.toFloat() / (list.size - 1) * w
            val normalized = ((list[i] - minHz) / (maxHz - minHz)).coerceIn(0f, 1f)
            val y = h - normalized * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        paint.color = 0xFF4A2E75.toInt()
        paint.strokeWidth = 5f
        canvas.drawPath(path, paint)
    }
}
