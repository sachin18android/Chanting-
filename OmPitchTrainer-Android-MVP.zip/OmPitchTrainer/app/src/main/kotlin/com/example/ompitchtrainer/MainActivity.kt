package com.example.ompitchtrainer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val sampleRate = 44100
    private val purple = Color.rgb(103, 55, 183)
    private val purpleDark = Color.rgb(62, 38, 90)
    private val bg = Color.rgb(250, 248, 253)
    private val green = Color.rgb(28, 165, 93)
    private val yellow = Color.rgb(220, 158, 20)
    private val red = Color.rgb(211, 67, 67)
    private val muted = Color.rgb(103, 96, 110)
    private val cardBorder = Color.rgb(232, 225, 239)

    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout
    private lateinit var trainerContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var settingsContainer: LinearLayout
    private lateinit var resultContainer: LinearLayout
    private lateinit var livePitch: TextView
    private lateinit var feedback: TextView
    private lateinit var targetView: TextView
    private lateinit var scoreView: TextView
    private lateinit var accuracyView: TextView
    private lateinit var stabilityView: TextView
    private lateinit var timerView: TextView
    private lateinit var statusView: TextView
    private lateinit var targetInput: EditText
    private lateinit var graph: PitchGraphView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var modeOm: Button
    private lateinit var modePhrase: Button

    private var mode = ChantMode.OM
    private var targetHz = 136.0
    private var running = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private val handler = Handler(Looper.getMainLooper())
    private val pitchHistory = ArrayDeque<Float>()
    private val samples = ArrayList<VoiceSample>()
    private var sessionStart = 0L
    private var sessionSeconds = 0
    private var smoothedPitch: Double? = null
    private var lastAcceptedPitch: Double? = null
    private var pcmBuffer = ByteArrayOutputStream()
    private var lastRecordingFile: File? = null
    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val prefs by lazy { getSharedPreferences("coach", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        tts = TextToSpeech(this, this)
        buildApp()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val hindi = tts?.setLanguage(Locale("hi", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (hindi == TextToSpeech.LANG_NOT_SUPPORTED || hindi == TextToSpeech.LANG_MISSING_DATA) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int = -1, h: Int = -2) = LinearLayout.LayoutParams(w, h)
    private fun cardLp() = lp().apply { setMargins(dp(12), dp(6), dp(12), dp(6)) }

    private fun tv(value: String, size: Float, color: Int = muted, gravity: Int = Gravity.START) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        this.gravity = gravity
        includeFontPadding = true
    }

    private fun button(value: String, primary: Boolean = false) = Button(this).apply {
        text = value
        textSize = 14f
        isAllCaps = false
        minHeight = dp(54)
        minWidth = 0
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setTextColor(if (primary) Color.WHITE else purpleDark)
        background = round(if (primary) purple else Color.WHITE, if (primary) purple else Color.rgb(207, 198, 214), dp(14), 1)
        stateListAnimator = null
    }

    private fun round(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(fill); setStroke(strokeWidth, stroke); cornerRadius = radius.toFloat()
    }

    private fun buildApp() {
        scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(tv("🕉  Om Pitch Trainer", 28f, purpleDark, Gravity.CENTER), lp().apply { bottomMargin = dp(2) })
        root.addView(tv("Train your pitch • Track your chanting consistency", 14f, muted, Gravity.CENTER), lp().apply { bottomMargin = dp(10) })

        trainerContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        settingsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        resultContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        buildTrainer(); buildHistory(); buildSettings()
        root.addView(trainerContainer); root.addView(historyContainer); root.addView(settingsContainer); root.addView(resultContainer); root.addView(bottomNav())
    }

    private fun sectionTitle(s: String) = tv(s, 13f, muted).apply { setPadding(dp(4), dp(8), dp(4), dp(5)) }

    private fun buildTrainer() {
        trainerContainer.removeAllViews()
        trainerContainer.addView(sectionTitle("CHANTING MODE"))
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeOm = button("ॐ", mode == ChantMode.OM)
        modePhrase = button("ॐ नमः शिवाय", mode == ChantMode.PHRASE)
        modes.addView(modeOm, weight(56).apply { rightMargin = dp(5) })
        modes.addView(modePhrase, weight(56).apply { leftMargin = dp(5) })
        trainerContainer.addView(modes, lp().apply { bottomMargin = dp(8) })
        modeOm.setOnClickListener { if (!running) { mode = ChantMode.OM; refreshModeButtons() } }
        modePhrase.setOnClickListener { if (!running) { mode = ChantMode.PHRASE; refreshModeButtons() } }

        trainerContainer.addView(sectionTitle("TARGET PITCH (Hz)"))
        val targetRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val minus = button("−"); val plus = button("+")
        targetInput = EditText(this).apply {
            setText("136"); textSize = 24f; gravity = Gravity.CENTER; setSingleLine(true); setTextColor(purpleDark)
            background = round(Color.WHITE, Color.rgb(193, 174, 208), dp(14), 1)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        targetRow.addView(minus, LinearLayout.LayoutParams(dp(58), dp(58)))
        targetRow.addView(targetInput, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(10); rightMargin = dp(10) })
        targetRow.addView(plus, LinearLayout.LayoutParams(dp(58), dp(58)))
        trainerContainer.addView(targetRow, lp().apply { bottomMargin = dp(8) })
        minus.setOnClickListener { setTarget(targetHz - 1) }; plus.setOnClickListener { setTarget(targetHz + 1) }

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val guideButton = button(if (mode == ChantMode.OM) "▶  Play Mantra Guide" else "▶  Play Mantra Guide")
        val toneButton = button("♪  Pitch Tone")
        actionRow.addView(guideButton, weight(58).apply { rightMargin = dp(5) })
        actionRow.addView(toneButton, weight(58).apply { leftMargin = dp(5) })
        trainerContainer.addView(actionRow, lp().apply { bottomMargin = dp(6) })
        guideButton.setOnClickListener { playMantraGuide() }
        toneButton.setOnClickListener { playPitchTone() }

        targetView = tv("ॐ mode • Target: 136 Hz", 15f, purpleDark, Gravity.CENTER)
        trainerContainer.addView(targetView, lp().apply { bottomMargin = dp(8) })

        val liveCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = round(Color.WHITE, cardBorder, dp(20), 1); setPadding(dp(16), dp(12), dp(16), dp(14)) }
        liveCard.addView(sectionTitle("CURRENT PITCH"))
        livePitch = tv("— Hz", 40f, purple, Gravity.CENTER)
        liveCard.addView(livePitch, lp().apply { bottomMargin = dp(2) })
        feedback = tv("Microphone ready", 17f, muted, Gravity.CENTER)
        liveCard.addView(feedback, lp().apply { bottomMargin = dp(6) })
        liveCard.addView(tv("Target is a practice reference, not a universally ‘correct’ frequency.", 11f, muted, Gravity.CENTER))
        trainerContainer.addView(liveCard, cardLp())

        graph = PitchGraphView(this, purple)
        trainerContainer.addView(graph, lp().apply { setMargins(dp(12), dp(6), dp(12), dp(8)); height = dp(245) })

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        accuracyView = metric("Accuracy", "—"); stabilityView = metric("Stability", "—"); scoreView = metric("Consistency", "—")
        metrics.addView(metricBox(accuracyView), metricLp()); metrics.addView(metricBox(stabilityView), metricLp()); metrics.addView(metricBox(scoreView), metricLp())
        trainerContainer.addView(metrics, lp().apply { bottomMargin = dp(8) })

        val timerCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = round(Color.rgb(246,242,251), cardBorder, dp(16), 1); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        timerCard.addView(tv("⏱  SESSION TIME", 11f, muted, Gravity.CENTER))
        timerView = tv("00:00", 22f, purpleDark, Gravity.CENTER); timerCard.addView(timerView)
        trainerContainer.addView(timerCard, cardLp())
        statusView = tv("Keep the phone 20–40 cm away • Tap Start", 13f, muted, Gravity.CENTER)
        trainerContainer.addView(statusView, lp().apply { bottomMargin = dp(7) })

        startButton = button("🎤  START CHANTING", true)
        stopButton = button("■  STOP").apply { isEnabled = false; alpha = .5f }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(startButton, weight(60).apply { rightMargin = dp(5) }); controls.addView(stopButton, weight(60).apply { leftMargin = dp(5) })
        trainerContainer.addView(controls, lp())
        startButton.setOnClickListener { startSession() }; stopButton.setOnClickListener { stopSession(true) }
    }

    private fun weight(h: Int) = LinearLayout.LayoutParams(0, dp(h), 1f)
    private fun metric(label: String, value: String) = tv("$label\n$value", 14f, purpleDark, Gravity.CENTER)
    private fun metricLp() = LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(3); rightMargin = dp(3) }
    private fun metricBox(v: TextView) = LinearLayout(this).apply { background = round(Color.WHITE, cardBorder, dp(16), 1); gravity = Gravity.CENTER; addView(v) }

    private fun refreshModeButtons() {
        val omSelected = mode == ChantMode.OM
        modeOm.background = round(if (omSelected) purple else Color.WHITE, if (omSelected) purple else Color.rgb(207,198,214), dp(14), 1)
        modePhrase.background = round(if (!omSelected) purple else Color.WHITE, if (!omSelected) purple else Color.rgb(207,198,214), dp(14), 1)
        modeOm.setTextColor(if (omSelected) Color.WHITE else purpleDark); modePhrase.setTextColor(if (!omSelected) Color.WHITE else purpleDark)
        targetView.text = if (omSelected) "ॐ mode • Target: ${fmt(targetHz)} Hz" else "ॐ नमः शिवाय mode • Target: ${fmt(targetHz)} Hz"
    }

    private fun setTarget(v: Double) { targetHz = v.coerceIn(60.0, 400.0); targetInput.setText(fmt(targetHz)); refreshModeButtons(); graph.setTarget(targetHz.toFloat()) }

    private fun buildHistory() {
        historyContainer.removeAllViews(); historyContainer.addView(tv("Practice History", 25f, purpleDark), lp().apply { bottomMargin = dp(8) })
        val entries = prefs.getStringSet("history", emptySet())?.toList()?.sortedByDescending { it.substringBefore("~").toLongOrNull() ?: 0L } ?: emptyList()
        if (entries.isEmpty()) {
            historyContainer.addView(tv("No sessions yet. Complete your first practice session and it will appear here.", 15f, muted, Gravity.CENTER), lp().apply { topMargin = dp(50) }); return
        }
        entries.take(20).forEach { raw ->
            val p = raw.split("~")
            if (p.size >= 6) {
                val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, cardBorder, dp(16), 1); setPadding(dp(12), dp(8), dp(10), dp(8)) }
                val info = tv("${p[1]}\n${p[2]} Hz • ${p[3]}", 13f, purpleDark)
                val score = tv("${p[4]}%", 20f, green, Gravity.END)
                val play = button("▶").apply { minHeight = dp(44); setOnClickListener { playRecording(File(p[5])) } }
                card.addView(info, LinearLayout.LayoutParams(0, dp(72), 1f)); card.addView(score, LinearLayout.LayoutParams(dp(62), dp(72))); card.addView(play, LinearLayout.LayoutParams(dp(54), dp(54)))
                historyContainer.addView(card, cardLp())
            }
        }
        val clear = button("Clear history"); clear.setOnClickListener { prefs.edit().remove("history").apply(); buildHistory() }
        historyContainer.addView(clear, lp().apply { topMargin = dp(8) })
    }

    private fun buildSettings() {
        settingsContainer.removeAllViews(); settingsContainer.addView(tv("Settings", 25f, purpleDark), lp().apply { bottomMargin = dp(12) })
        settingsContainer.addView(settingRow("Default target pitch", "${fmt(targetHz)} Hz") {
            val input = EditText(this).apply { setText(fmt(targetHz)); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
            android.app.AlertDialog.Builder(this).setTitle("Default target pitch").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> setTarget(input.text.toString().toDoubleOrNull() ?: 136.0) }.show()
        }, cardLp())
        settingsContainer.addView(settingRow("Microphone", if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "Permission: Allowed" else "Permission: Required") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }, cardLp())
        settingsContainer.addView(settingRow("Mantra guide", "Uses Android speech synthesis for the selected mantra") { playMantraGuide() }, cardLp())
        settingsContainer.addView(tv("Version 4.0 • Chanting Coach", 13f, muted), lp().apply { topMargin = dp(20) })
    }

    private fun settingRow(title: String, value: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, cardBorder, dp(16), 1); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnClickListener { click() }
        addView(tv(title, 15f, purpleDark)); addView(tv(value, 13f, muted).apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun bottomNav() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; background = android.graphics.drawable.ColorDrawable(Color.WHITE); setPadding(0, dp(8), 0, 0)
        val trainer = button("⌂\nTrainer"); val history = button("▥\nHistory"); val settings = button("⚙\nSettings")
        addView(trainer, weight(58)); addView(history, weight(58)); addView(settings, weight(58))
        trainer.setOnClickListener { showTab(0) }; history.setOnClickListener { buildHistory(); showTab(1) }; settings.setOnClickListener { buildSettings(); showTab(2) }
    }

    private fun showTab(tab: Int) { trainerContainer.visibility = if (tab == 0) View.VISIBLE else View.GONE; historyContainer.visibility = if (tab == 1) View.VISIBLE else View.GONE; settingsContainer.visibility = if (tab == 2) View.VISIBLE else View.GONE; resultContainer.visibility = View.GONE; scroll.post { scroll.smoothScrollTo(0, 0) } }

    private fun startSession() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100); return }
        targetHz = targetInput.text.toString().toDoubleOrNull()?.coerceIn(60.0, 400.0) ?: 136.0
        targetInput.setText(fmt(targetHz)); pitchHistory.clear(); samples.clear(); graph.clear(); graph.setTarget(targetHz.toFloat()); smoothedPitch = null; lastAcceptedPitch = null
        pcmBuffer = ByteArrayOutputStream(); sessionSeconds = 0; sessionStart = System.currentTimeMillis(); running = true
        startButton.isEnabled = false; startButton.alpha = .5f; stopButton.isEnabled = true; stopButton.alpha = 1f; targetInput.isEnabled = false; modeOm.isEnabled = false; modePhrase.isEnabled = false
        statusView.text = "🎤 Listening… your voice is being recorded"
        handler.post(timerRunnable); worker = Thread { recordLoop() }.also { it.start() }
    }

    private val timerRunnable = object : Runnable { override fun run() { if (!running) return; sessionSeconds = ((System.currentTimeMillis() - sessionStart) / 1000).toInt(); timerView.text = String.format(Locale.US, "%02d:%02d", sessionSeconds / 60, sessionSeconds % 60); handler.postDelayed(this, 500) } }

    private fun recordLoop() {
        var localRecorder: AudioRecord? = null
        try {
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) throw IllegalStateException("Microphone unavailable")
            localRecorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuffer * 2, 8192))
            recorder = localRecorder
            if (localRecorder.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Could not initialize microphone")
            localRecorder.startRecording()
            val buffer = ShortArray(4096)
            val rawBytes = ByteArray(buffer.size * 2)
            while (running) {
                val n = localRecorder.read(buffer, 0, buffer.size)
                if (n > 0) {
                    for (i in 0 until n) { val s = buffer[i].toInt(); rawBytes[i * 2] = (s and 0xff).toByte(); rawBytes[i * 2 + 1] = ((s shr 8) and 0xff).toByte() }
                    synchronized(pcmBuffer) { pcmBuffer.write(rawBytes, 0, n * 2) }
                }
                if (n > 2048) {
                    val detected = PitchDetector.detect(buffer, n, sampleRate); val now = System.currentTimeMillis() - sessionStart
                    if (detected != null) handler.post { if (running) acceptPitch(detected.pitchHz, detected.confidence, now) }
                }
            }
        } catch (t: Throwable) {
            handler.post { if (running) { statusView.text = "Microphone error: ${t.message ?: "unknown"}"; stopSession(false) } }
        } finally {
            try { localRecorder?.stop() } catch (_: Throwable) {}
            try { localRecorder?.release() } catch (_: Throwable) {}
            if (recorder === localRecorder) recorder = null
        }
    }

    private fun acceptPitch(raw: Double, confidence: Double, timeMs: Long) {
        if (confidence < 0.60 || raw !in 60.0..400.0) return
        var p = raw; val prev = smoothedPitch
        if (prev != null) { while (p / prev > 1.8) p /= 2.0; while (prev / p > 1.8) p *= 2.0; if (abs(1200.0 * log2(p / prev)) > 650) return }
        smoothedPitch = if (prev == null) p else prev * .72 + p * .28; p = smoothedPitch!!
        if (lastAcceptedPitch != null && abs(1200.0 * log2(p / lastAcceptedPitch!!)) > 450) return
        lastAcceptedPitch = p; pitchHistory.addLast(p.toFloat()); while (pitchHistory.size > 120) pitchHistory.removeFirst(); samples.add(VoiceSample(timeMs, p.toFloat()))
        val cents = 1200.0 * log2(p / targetHz); livePitch.text = String.format(Locale.US, "%.1f Hz", p); val absC = abs(cents)
        val color = when { absC <= 30 -> green; absC <= 70 -> yellow; else -> red }; livePitch.setTextColor(color); feedback.setTextColor(color)
        feedback.text = when { absC <= 30 -> "● Excellent — on target"; absC <= 70 -> "● Almost there — adjust slightly"; else -> "● Adjust your pitch toward target" } + String.format(Locale.US, "  •  %+.1f cents", cents)
        graph.addPitch(p.toFloat()); updateLiveMetrics()
    }

    private fun updateLiveMetrics() {
        if (pitchHistory.size < 5) return
        val vals = pitchHistory.toList().map { it.toDouble() }; val mean = vals.average(); val sd = sqrt(vals.map { (it - mean) * (it - mean) }.average())
        val acc = (100 - vals.map { abs(1200 * log2(it / targetHz)) }.average() / 3).coerceIn(0.0, 100.0); val stability = (100 - sd / targetHz * 500).coerceIn(0.0, 100.0); val score = (acc * .55 + stability * .45).coerceIn(0.0, 100.0)
        accuracyView.text = String.format(Locale.US, "Accuracy\n%.0f%%", acc); stabilityView.text = String.format(Locale.US, "Stability\n%.0f%%", stability); scoreView.text = String.format(Locale.US, "Consistency\n%.0f%%", score)
    }

    private fun stopSession(showResult: Boolean) {
        if (!running && recorder == null) return
        running = false; handler.removeCallbacks(timerRunnable)
        try { recorder?.stop() } catch (_: Throwable) {}
        try { worker?.join(500) } catch (_: Throwable) {}
        recorder = null; worker = null
        startButton.isEnabled = true; startButton.alpha = 1f; stopButton.isEnabled = false; stopButton.alpha = .5f; targetInput.isEnabled = true; modeOm.isEnabled = true; modePhrase.isEnabled = true
        lastRecordingFile = saveRecording()
        statusView.text = if (lastRecordingFile != null) "Session saved • Tap Play Recording to hear it back" else "Session complete • Ready for another round"
        if (showResult && samples.isNotEmpty()) showResult()
    }

    private fun saveRecording(): File? {
        val bytes = synchronized(pcmBuffer) { pcmBuffer.toByteArray() }; if (bytes.isEmpty()) return null
        val file = File(filesDir, "chant_${System.currentTimeMillis()}.wav")
        return try { writeWav(file, bytes, sampleRate, 1, 16); file } catch (_: Throwable) { null }
    }

    private fun writeWav(file: File, pcm: ByteArray, rate: Int, channels: Int, bits: Int) {
        FileOutputStream(file).use { out ->
            val dataLen = pcm.size; val byteRate = rate * channels * bits / 8; val blockAlign = channels * bits / 8
            fun le(v: Int) { out.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte(), ((v shr 16) and 255).toByte(), ((v shr 24) and 255).toByte())) }
            fun le16(v: Int) { out.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte())) }
            out.write("RIFF".toByteArray()); le(36 + dataLen); out.write("WAVEfmt ".toByteArray()); le(16); le16(1); le16(channels); le(rate); le(byteRate); le16(blockAlign); le16(bits); out.write("data".toByteArray()); le(dataLen); out.write(pcm)
        }
    }

    private fun playRecording(file: File?) {
        if (file == null || !file.exists()) { Toast.makeText(this, "Recording is not available", Toast.LENGTH_SHORT).show(); return }
        try { mediaPlayer?.release(); mediaPlayer = MediaPlayer().apply { setDataSource(file.absolutePath); setOnCompletionListener { release(); mediaPlayer = null }; prepare(); start() } }
        catch (t: Throwable) { Toast.makeText(this, "Could not play recording", Toast.LENGTH_SHORT).show() }
    }

    private fun playMantraGuide() {
        if (!ttsReady) { Toast.makeText(this, "Speech engine is still starting", Toast.LENGTH_SHORT).show(); return }
        val phrase = if (mode == ChantMode.OM) "ॐ" else "ॐ नमः शिवाय"
        tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "mantra")
        Toast.makeText(this, "Playing ${if (mode == ChantMode.OM) "Om" else "Om Namah Shivaya"} guide", Toast.LENGTH_SHORT).show()
    }

    private fun playPitchTone() {
        val hz = targetInput.text.toString().toDoubleOrNull()?.coerceIn(60.0, 400.0) ?: targetHz
        Thread {
            try {
                val count = sampleRate * 1800 / 1000; val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuffer <= 0) throw IllegalStateException()
                val track = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setBufferSizeInBytes(max(minBuffer, 8192)).setTransferMode(AudioTrack.MODE_STREAM).build()
                if (track.state != AudioTrack.STATE_INITIALIZED) throw IllegalStateException()
                track.play(); val buf = ShortArray(1024); var index = 0
                while (index < count) { val n = min(buf.size, count - index); for (i in 0 until n) { val t = (index + i).toDouble() / sampleRate; val fade = min(1.0, t / .08) * min(1.0, ((count.toDouble() / sampleRate) - t) / .12).coerceAtLeast(0.0); buf[i] = (sin(2 * Math.PI * hz * t) * 7000 * fade).toInt().toShort() }; track.write(buf, 0, n); index += n }
                track.stop(); track.release()
            } catch (_: Throwable) { handler.post { Toast.makeText(this, "Pitch tone could not be played", Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun showResult() {
        trainerContainer.visibility = View.GONE; historyContainer.visibility = View.GONE; settingsContainer.visibility = View.GONE; resultContainer.visibility = View.VISIBLE; resultContainer.removeAllViews()
        val m = finalMetrics()
        resultContainer.addView(tv("Session Complete", 27f, purpleDark, Gravity.CENTER), lp().apply { bottomMargin = dp(5) })
        resultContainer.addView(tv(if (m.score >= 85) "🏆 Great chanting!" else if (m.score >= 70) "✨ Good practice" else "🌱 Keep practising", 22f, purple, Gravity.CENTER), lp().apply { bottomMargin = dp(12) })
        resultContainer.addView(scoreCard(m), cardLp())
        if (lastRecordingFile != null) {
            val replay = button("▶  Play My Recording", true); resultContainer.addView(replay, lp().apply { setMargins(dp(12), dp(8), dp(12), dp(5)) }); replay.setOnClickListener { playRecording(lastRecordingFile) }
        }
        if (mode == ChantMode.PHRASE) resultContainer.addView(phraseAnalysis(), cardLp())
        val save = button("💾 Save Session"); val again = button("↻ Practice Again")
        resultContainer.addView(save, lp().apply { setMargins(dp(12), dp(5), dp(12), dp(5)) }); resultContainer.addView(again, lp().apply { setMargins(dp(12), dp(2), dp(12), dp(6)) })
        save.setOnClickListener { saveHistory(m); save.isEnabled = false; save.text = "✓ Session Saved" }
        again.setOnClickListener { showTab(0); resetSession() }
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun scoreCard(m: Metrics) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, cardBorder, dp(20), 1); setPadding(dp(18), dp(18), dp(18), dp(18))
        addView(tv(String.format(Locale.US, "Overall Score\n%.0f / 100", m.score), 29f, if (m.score >= 85) green else if (m.score >= 70) yellow else red, Gravity.CENTER))
        addView(tv(String.format(Locale.US, "Pitch Accuracy  %.0f%%     Stability  %.0f%%     Consistency  %.0f%%", m.accuracy, m.stability, m.score), 12f, muted, Gravity.CENTER).apply { setPadding(0, dp(12), 0, 0) })
        addView(tv(String.format(Locale.US, "Target %s Hz  •  Average %s Hz  •  Duration %02d:%02d", fmt(targetHz), fmt(m.average), sessionSeconds / 60, sessionSeconds % 60), 12f, muted, Gravity.CENTER).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun phraseAnalysis() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, cardBorder, dp(20), 1); setPadding(dp(16), dp(14), dp(16), dp(14)); addView(tv("ॐ नमः शिवाय — practice analysis", 18f, purpleDark)); addView(tv("The app estimates voiced segments; it does not claim exact Sanskrit syllable recognition.", 11f, muted).apply { setPadding(0, dp(4), 0, dp(8)) })
        val segments = findSegments().take(3); listOf("ॐ", "नमः", "शिवाय").forEachIndexed { i, label -> val seg = segments.getOrNull(i); val vals = seg?.map { it.pitch } ?: emptyList(); val avg = if (vals.isEmpty()) 0.0 else vals.average().toDouble(); val acc = if (vals.isEmpty()) 0.0 else (100 - vals.map { abs(1200 * log2(it / targetHz)) }.average() / 3).coerceIn(0.0, 100.0); addView(tv(if (vals.isEmpty()) "$label    — not confidently detected" else String.format(Locale.US, "$label    %.1f Hz   •   %.0f%% pitch match", avg, acc), 15f, if (vals.isEmpty()) muted else purpleDark).apply { setPadding(0, dp(5), 0, dp(5)) }) }
    }

    private fun findSegments(): List<List<VoiceSample>> {
        if (samples.isEmpty()) return emptyList(); val result = ArrayList<MutableList<VoiceSample>>(); var current = mutableListOf<VoiceSample>(); var last = -1L
        for (s in samples) { if (last >= 0 && s.timeMs - last > 300 && current.isNotEmpty()) { result.add(current); current = mutableListOf() }; current.add(s); last = s.timeMs }; if (current.isNotEmpty()) result.add(current); return result.sortedByDescending { it.size }
    }

    private fun finalMetrics(): Metrics {
        val vals = samples.map { it.pitch.toDouble() }; if (vals.isEmpty()) return Metrics(0.0, 0.0, 0.0, 0.0, targetHz)
        val avg = vals.average(); val sd = sqrt(vals.map { (it - avg) * (it - avg) }.average()); val accuracy = (100 - vals.map { abs(1200 * log2(it / targetHz)) }.average() / 3).coerceIn(0.0, 100.0); val stability = (100 - sd / targetHz * 500).coerceIn(0.0, 100.0); val score = (accuracy * .55 + stability * .45).coerceIn(0.0, 100.0); return Metrics(score, accuracy, stability, score, avg)
    }

    private fun saveHistory(m: Metrics) {
        val file = lastRecordingFile?.absolutePath ?: ""; val date = SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date()); val entry = "${System.currentTimeMillis()}~$date~${fmt(targetHz)}~${if (mode == ChantMode.OM) "ॐ" else "ॐ नमः शिवाय"}~${m.score.toInt()}~$file"; val set = prefs.getStringSet("history", emptySet())?.toMutableSet() ?: mutableSetOf(); set.add(entry); while (set.size > 20) set.remove(set.minByOrNull { it.substringBefore("~").toLongOrNull() ?: 0L } ?: entry); prefs.edit().putStringSet("history", set).apply()
    }

    private fun resetSession() { stopSession(false); pitchHistory.clear(); samples.clear(); graph.clear(); livePitch.text = "— Hz"; livePitch.setTextColor(purple); feedback.text = "Microphone ready"; feedback.setTextColor(muted); accuracyView.text = "Accuracy\n—"; stabilityView.text = "Stability\n—"; scoreView.text = "Consistency\n—"; timerView.text = "00:00"; statusView.text = "Keep the phone 20–40 cm away • Tap Start" }
    private fun fmt(v: Double): String = if (abs(v - v.toInt()) < .05) v.toInt().toString() else String.format(Locale.US, "%.1f", v)

    override fun onBackPressed() { if (resultContainer.visibility == View.VISIBLE) { showTab(0); return }; super.onBackPressed() }
    override fun onDestroy() { stopSession(false); mediaPlayer?.release(); tts?.stop(); tts?.shutdown(); super.onDestroy() }

    data class VoiceSample(val timeMs: Long, val pitch: Float)
    data class Metrics(val score: Double, val accuracy: Double, val stability: Double, val consistency: Double, val average: Double)
    enum class ChantMode { OM, PHRASE }

    class PitchGraphView(context: Context, private val lineColor: Int) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG); private val values = ArrayDeque<Float>(); private var target = 136f
        fun setTarget(t: Float) { target = t; invalidate() }; fun addPitch(v: Float) { values.addLast(v); while (values.size > 120) values.removeFirst(); invalidate() }; fun clear() { values.clear(); invalidate() }
        override fun onDraw(c: Canvas) { val w = width.toFloat(); val h = height.toFloat(); paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawRoundRect(0f, 0f, w, h, 22f, 22f, paint); val minHz = max(60f, target - 50); val maxHz = target + 50; paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(190, 176, 202); val y = h - ((target - minHz) / (maxHz - minHz)) * h; c.drawLine(0f, y, w, y, paint); if (values.size < 2) return; val list = values.toList(); val path = Path(); for (i in list.indices) { val x = i.toFloat() / (list.size - 1) * w; val n = ((list[i] - minHz) / (maxHz - minHz)).coerceIn(0f, 1f); val py = h - n * h; if (i == 0) path.moveTo(x, py) else path.lineTo(x, py) }; paint.color = lineColor; paint.strokeWidth = 4f * resources.displayMetrics.density; c.drawPath(path, paint); paint.style = Paint.Style.FILL; paint.color = Color.rgb(125, 106, 145); paint.textSize = 14f * resources.displayMetrics.scaledDensity; c.drawText(String.format(Locale.US, "Target %.0f Hz", target), dp(10).toFloat(), dp(22).toFloat(), paint) }
        private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()
    }

    object PitchDetector {
        fun detect(samples: ShortArray, n: Int, sampleRate: Int): PitchResult? { var energy = 0.0; for (i in 0 until n) { val x = samples[i] / 32768.0; energy += x * x }; val rms = sqrt(energy / n); if (rms < .012) return null; val minLag = sampleRate / 400; val maxLag = min(sampleRate / 60, n - 2); var bestLag = -1; var best = 0.0; for (lag in minLag..maxLag) { var sum = 0.0; var e1 = 0.0; var e2 = 0.0; val limit = n - lag; for (i in 0 until limit) { val x = samples[i] / 32768.0; val y = samples[i + lag] / 32768.0; sum += x * y; e1 += x * x; e2 += y * y }; val d = sqrt(e1 * e2); if (d > 0) { val corr = sum / d; if (corr > best) { best = corr; bestLag = lag } } }; if (bestLag <= 0 || best < .55) return null; return PitchResult(sampleRate / bestLag.toDouble(), best) }
    }
    data class PitchResult(val pitchHz: Double, val confidence: Double)
}
