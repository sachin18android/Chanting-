package com.example.ompitchtrainer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : Activity() {
    // A broadly supported audio rate used consistently for microphone capture and reference-tone playback.
    private val sampleRate = 44100
    private val purple = Color.rgb(92, 52, 145)
    private val purpleDark = Color.rgb(55, 31, 86)
    private val bg = Color.rgb(249, 247, 252)
    private val green = Color.rgb(22, 158, 87)
    private val yellow = Color.rgb(211, 143, 18)
    private val red = Color.rgb(205, 55, 55)
    private val muted = Color.rgb(100, 91, 108)

    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout
    private lateinit var livePitch: TextView
    private lateinit var feedback: TextView
    private lateinit var targetView: TextView
    private lateinit var scoreView: TextView
    private lateinit var timerView: TextView
    private lateinit var statusView: TextView
    private lateinit var targetInput: EditText
    private lateinit var graph: PitchGraphView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var referenceButton: Button
    private lateinit var modeOm: Button
    private lateinit var modePhrase: Button
    private lateinit var resultContainer: LinearLayout
    private lateinit var trainerContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var settingsContainer: LinearLayout

    private var mode = ChantMode.OM
    private var targetHz = 136.0
    private var running = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private val handler = Handler(Looper.getMainLooper())
    private val pitchHistory = ArrayDeque<Float>()
    private val samples = ArrayList<VoiceSample>()
    private var sessionStart = 0L
    private var sessionSeconds = 0
    private var smoothedPitch: Double? = null
    private var lastAcceptedPitch: Double? = null
    private var referenceTrack: AudioTrack? = null

    private val prefs by lazy { getSharedPreferences("coach", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildApp()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int = -1, h: Int = -2): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)
    private fun cardLp(): LinearLayout.LayoutParams = lp().apply { setMargins(dp(12), dp(6), dp(12), dp(6)) }

    private fun text(value: String, size: Float, color: Int = muted, gravity: Int = Gravity.START): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); this.gravity = gravity
    }

    private fun button(value: String, primary: Boolean = false): Button = Button(this).apply {
        text = value; textSize = 14f; isAllCaps = false
        setTextColor(if (primary) Color.WHITE else purpleDark)
        background = round(if (primary) purple else Color.WHITE, if (primary) purple else Color.rgb(205, 194, 214), dp(14), if (primary) 1 else 1)
        minHeight = dp(52)
        stateListAnimator = null
    }

    private fun round(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(fill); setStroke(strokeWidth, stroke); cornerRadius = radius.toFloat()
    }

    private fun buildApp() {
        scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("🕉  Om Pitch Trainer", 28f, purpleDark, Gravity.CENTER), lp().apply { bottomMargin = dp(2) })
        root.addView(text("Train your pitch • Track your chanting consistency", 14f, muted, Gravity.CENTER), lp().apply { bottomMargin = dp(12) })

        trainerContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        settingsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        resultContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        buildTrainer()
        buildHistory()
        buildSettings()

        root.addView(trainerContainer)
        root.addView(historyContainer)
        root.addView(settingsContainer)
        root.addView(resultContainer)
        root.addView(bottomNav())
    }

    private fun sectionTitle(s: String) = text(s, 13f, muted).apply { setPadding(dp(4), dp(10), dp(4), dp(5)) }

    private fun buildTrainer() {
        trainerContainer.removeAllViews()
        trainerContainer.addView(sectionTitle("CHANTING MODE"))
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeOm = button("ॐ", mode == ChantMode.OM)
        modePhrase = button("ॐ नमः शिवाय", mode == ChantMode.PHRASE)
        modes.addView(modeOm, LinearLayout.LayoutParams(0, dp(56), 1f).apply { rightMargin = dp(5) })
        modes.addView(modePhrase, LinearLayout.LayoutParams(0, dp(56), 1f).apply { leftMargin = dp(5) })
        trainerContainer.addView(modes, lp().apply { bottomMargin = dp(8) })
        modeOm.setOnClickListener { mode = ChantMode.OM; refreshModeButtons() }
        modePhrase.setOnClickListener { mode = ChantMode.PHRASE; refreshModeButtons() }

        trainerContainer.addView(sectionTitle("TARGET PITCH (Hz)"))
        val targetRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val minus = button("−")
        val plus = button("+")
        targetInput = EditText(this).apply {
            setText(String.format(Locale.US, "%.0f", targetHz)); textSize = 24f; gravity = Gravity.CENTER; setSingleLine(true)
            setTextColor(purpleDark); background = round(Color.WHITE, Color.rgb(193, 174, 208), dp(14), dp(1))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        targetRow.addView(minus, LinearLayout.LayoutParams(dp(58), dp(58)))
        targetRow.addView(targetInput, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(10); rightMargin = dp(10) })
        targetRow.addView(plus, LinearLayout.LayoutParams(dp(58), dp(58)))
        trainerContainer.addView(targetRow, lp().apply { bottomMargin = dp(8) })
        minus.setOnClickListener { setTarget(targetHz - 1) }
        plus.setOnClickListener { setTarget(targetHz + 1) }

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        referenceButton = button("▶  Play Reference Tone")
        val reset = button("↻  Reset")
        actionRow.addView(referenceButton, LinearLayout.LayoutParams(0, dp(58), 1f).apply { rightMargin = dp(5) })
        actionRow.addView(reset, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(5) })
        trainerContainer.addView(actionRow, lp().apply { bottomMargin = dp(8) })
        referenceButton.setOnClickListener { playReferenceTone() }
        reset.setOnClickListener { resetSession() }

        targetView = text("ॐ mode • Target: 136 Hz", 15f, purpleDark, Gravity.CENTER)
        trainerContainer.addView(targetView, lp().apply { bottomMargin = dp(8) })

        val liveCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = round(Color.WHITE, Color.rgb(235, 229, 240), dp(20), 1); setPadding(dp(16), dp(12), dp(16), dp(12)) }
        liveCard.addView(sectionTitle("CURRENT PITCH"))
        livePitch = text("— Hz", 38f, purple, Gravity.CENTER)
        liveCard.addView(livePitch, lp().apply { bottomMargin = dp(2) })
        feedback = text("Waiting for voice…", 17f, muted, Gravity.CENTER)
        liveCard.addView(feedback, lp().apply { bottomMargin = dp(4) })
        liveCard.addView(text("Target is a practice reference, not a universally ‘correct’ frequency.", 11f, muted, Gravity.CENTER))
        trainerContainer.addView(liveCard, cardLp())

        graph = PitchGraphView(this, purple)
        trainerContainer.addView(graph, LinearLayout.LayoutParams(-1, dp(235)).apply { setMargins(dp(12), dp(6), dp(12), dp(6)) })

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scoreView = metric("Consistency", "—")
        val accuracy = metric("Accuracy", "—")
        val stability = metric("Stability", "—")
        metrics.addView(metricBox(scoreView), weightBox())
        metrics.addView(metricBox(accuracy), weightBox())
        metrics.addView(metricBox(stability), weightBox())
        trainerContainer.addView(metrics, lp().apply { bottomMargin = dp(8) })

        timerView = text("Session: 00:00", 15f, muted, Gravity.CENTER)
        trainerContainer.addView(timerView, lp())
        statusView = text("Microphone ready • Tap Start", 14f, muted, Gravity.CENTER)
        trainerContainer.addView(statusView, lp().apply { bottomMargin = dp(6) })

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startButton = button("🎤  START CHANTING", true)
        stopButton = button("■  STOP").apply { isEnabled = false; alpha = 0.5f }
        controls.addView(startButton, weightButton())
        controls.addView(stopButton, weightButton())
        trainerContainer.addView(controls, lp())
        startButton.setOnClickListener { startSession() }
        stopButton.setOnClickListener { stopSession(true) }
    }

    private fun weightButton() = LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) }
    private fun weightBox() = LinearLayout.LayoutParams(0, dp(86), 1f).apply { leftMargin = dp(3); rightMargin = dp(3) }

    private fun metric(label: String, value: String) = text("$label\n$value", 15f, purpleDark, Gravity.CENTER)
    private fun metricBox(v: TextView) = LinearLayout(this).apply { background = round(Color.WHITE, Color.rgb(235, 229, 240), dp(16), 1); gravity = Gravity.CENTER; addView(v) }

    private fun refreshModeButtons() {
        modeOm.background = round(if (mode == ChantMode.OM) purple else Color.WHITE, if (mode == ChantMode.OM) purple else Color.rgb(205,194,214), dp(14), 1)
        modeOm.setTextColor(if (mode == ChantMode.OM) Color.WHITE else purpleDark)
        modePhrase.background = round(if (mode == ChantMode.PHRASE) purple else Color.WHITE, if (mode == ChantMode.PHRASE) purple else Color.rgb(205,194,214), dp(14), 1)
        modePhrase.setTextColor(if (mode == ChantMode.PHRASE) Color.WHITE else purpleDark)
        targetView.text = if (mode == ChantMode.OM) "ॐ mode • Target: ${fmt(targetHz)} Hz" else "ॐ नमः शिवाय mode • Target: ${fmt(targetHz)} Hz"
    }

    private fun setTarget(v: Double) {
        targetHz = v.coerceIn(60.0, 400.0)
        targetInput.setText(fmt(targetHz))
        refreshModeButtons()
        graph.setTarget(targetHz.toFloat())
    }

    private fun buildHistory() {
        historyContainer.removeAllViews()
        historyContainer.addView(text("Practice History", 25f, purpleDark), lp().apply { bottomMargin = dp(8) })
        val entries = prefs.getStringSet("history", emptySet())?.toList()?.sortedDescending() ?: emptyList()
        if (entries.isEmpty()) {
            historyContainer.addView(text("No sessions yet. Complete your first practice session and it will appear here.", 15f, muted, Gravity.CENTER), lp().apply { topMargin = dp(50) })
            return
        }
        entries.take(20).forEach { raw ->
            val p = raw.split("~")
            if (p.size >= 5) {
                val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, Color.rgb(235,229,240), dp(16), 1); setPadding(dp(14), dp(10), dp(14), dp(10)) }
                val info = text("${p[1]}\n${p[2]} Hz • ${p[3]}", 14f, purpleDark)
                val score = text("${p[4]}%", 22f, green, Gravity.END)
                card.addView(info, LinearLayout.LayoutParams(0, dp(72), 1f))
                card.addView(score, LinearLayout.LayoutParams(dp(70), dp(72)))
                historyContainer.addView(card, cardLp())
            }
        }
        val clear = button("Clear history")
        clear.setOnClickListener { prefs.edit().remove("history").apply(); buildHistory() }
        historyContainer.addView(clear, lp().apply { topMargin = dp(8) })
    }

    private fun buildSettings() {
        settingsContainer.removeAllViews()
        settingsContainer.addView(text("Settings", 25f, purpleDark), lp().apply { bottomMargin = dp(12) })
        settingsContainer.addView(settingRow("Default target pitch", "${fmt(targetHz)} Hz") {
            val input = EditText(this); input.setText(fmt(targetHz)); input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            AlertDialogBuilder(this, "Default target pitch", input) { setTarget(input.text.toString().toDoubleOrNull() ?: 136.0) }
        }, cardLp())
        settingsContainer.addView(settingRow("Microphone", "Permission: ${if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "Allowed" else "Required"}") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }, cardLp())
        settingsContainer.addView(text("Version 3.0 • Chanting Coach", 13f, muted), lp().apply { topMargin = dp(20) })
    }

    private fun settingRow(title: String, value: String, click: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, Color.rgb(235,229,240), dp(16), 1); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnClickListener { click() }
        addView(text(title, 15f, purpleDark)); addView(text(value, 13f, muted).apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun AlertDialogBuilder(context: Context, title: String, input: EditText, save: () -> Unit) {
        android.app.AlertDialog.Builder(context).setTitle(title).setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> save() }.show()
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = ColorDrawableCompat(Color.WHITE); setPadding(0, dp(8), 0, 0) }
        val trainer = button("⌂\nTrainer")
        val history = button("▥\nHistory")
        val settings = button("⚙\nSettings")
        nav.addView(trainer, weightButton()); nav.addView(history, weightButton()); nav.addView(settings, weightButton())
        trainer.setOnClickListener { showTab(0) }; history.setOnClickListener { buildHistory(); showTab(1) }; settings.setOnClickListener { buildSettings(); showTab(2) }
        return nav
    }

    private fun showTab(tab: Int) {
        trainerContainer.visibility = if (tab == 0) View.VISIBLE else View.GONE
        historyContainer.visibility = if (tab == 1) View.VISIBLE else View.GONE
        settingsContainer.visibility = if (tab == 2) View.VISIBLE else View.GONE
        resultContainer.visibility = View.GONE
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun startSession() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        targetHz = targetInput.text.toString().toDoubleOrNull()?.coerceIn(60.0, 400.0) ?: 136.0
        targetInput.setText(fmt(targetHz))
        pitchHistory.clear(); samples.clear(); graph.clear(); graph.setTarget(targetHz.toFloat())
        smoothedPitch = null; lastAcceptedPitch = null; sessionSeconds = 0; sessionStart = System.currentTimeMillis(); running = true
        startButton.isEnabled = false; startButton.alpha = 0.5f; stopButton.isEnabled = true; stopButton.alpha = 1f
        targetInput.isEnabled = false; referenceButton.isEnabled = false
        statusView.text = "🎤 Listening… chant naturally"
        handler.post(timerRunnable)
        worker = Thread { recordLoop() }.also { it.start() }
    }

    private val timerRunnable = object : Runnable { override fun run() {
        if (!running) return
        sessionSeconds = ((System.currentTimeMillis() - sessionStart) / 1000).toInt()
        timerView.text = String.format(Locale.US, "Session: %02d:%02d", sessionSeconds / 60, sessionSeconds % 60)
        handler.postDelayed(this, 500)
    }}

    private fun recordLoop() {
        try {
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) throw IllegalStateException("Microphone unavailable")
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuffer * 2, 8192))
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Could not initialize microphone")
            recorder?.startRecording()
            val buffer = ShortArray(4096)
            while (running) {
                val n = recorder?.read(buffer, 0, buffer.size) ?: 0
                if (n > 2048) {
                    val detected = PitchDetector.detect(buffer, n, sampleRate)
                    val now = System.currentTimeMillis() - sessionStart
                    if (detected != null) handler.post { if (running) acceptPitch(detected.pitchHz, detected.confidence, now) }
                }
            }
        } catch (t: Throwable) {
            handler.post { statusView.text = "Microphone error: ${t.message ?: "unknown"}"; stopSession(false) }
        }
    }

    private fun acceptPitch(raw: Double, confidence: Double, timeMs: Long) {
        if (confidence < 0.60 || raw !in 60.0..400.0) return
        var p = raw
        val prev = smoothedPitch
        if (prev != null) {
            while (p / prev > 1.8) p /= 2.0
            while (prev / p > 1.8) p *= 2.0
            if (abs(1200.0 * log2(p / prev)) > 650) return
        }
        smoothedPitch = if (prev == null) p else prev * 0.72 + p * 0.28
        p = smoothedPitch!!
        if (lastAcceptedPitch != null && abs(1200.0 * log2(p / lastAcceptedPitch!!)) > 450) return
        lastAcceptedPitch = p
        pitchHistory.addLast(p.toFloat()); while (pitchHistory.size > 120) pitchHistory.removeFirst()
        samples.add(VoiceSample(timeMs, p.toFloat()))

        val cents = 1200.0 * log2(p / targetHz)
        livePitch.text = String.format(Locale.US, "%.1f Hz", p)
        val absC = abs(cents)
        val level = when { absC <= 30 -> 0; absC <= 70 -> 1; else -> 2 }
        val color = if (level == 0) green else if (level == 1) yellow else red
        livePitch.setTextColor(color); feedback.setTextColor(color)
        feedback.text = when (level) { 0 -> "● Excellent — on target"; 1 -> "● Almost there — adjust slightly"; else -> "● Adjust your pitch toward target" }
        feedback.text = String.format(Locale.US, "%s  •  %+.1f cents", feedback.text, cents)
        graph.addPitch(p.toFloat())
        updateLiveMetrics()
    }

    private fun updateLiveMetrics() {
        if (pitchHistory.size < 5) return
        val vals = pitchHistory.toList().map { it.toDouble() }
        val mean = vals.average(); val sd = sqrt(vals.map { (it - mean) * (it - mean) }.average())
        val acc = (100.0 - vals.map { abs(1200.0 * log2(it / targetHz)) }.average() / 3.0).coerceIn(0.0, 100.0)
        val stability = (100.0 - sd / targetHz * 500.0).coerceIn(0.0, 100.0)
        val score = (acc * 0.55 + stability * 0.45).coerceIn(0.0, 100.0)
        scoreView.text = String.format(Locale.US, "Consistency\n%.0f%%", score)
    }

    private fun stopSession(showResult: Boolean) {
        if (!running && recorder == null) return
        running = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null; worker = null
        handler.removeCallbacks(timerRunnable)
        startButton.isEnabled = true; startButton.alpha = 1f; stopButton.isEnabled = false; stopButton.alpha = 0.5f
        targetInput.isEnabled = true; referenceButton.isEnabled = true
        statusView.text = "Session complete • Ready for another round"
        if (showResult && samples.isNotEmpty()) showResult()
    }

    private fun resetSession() {
        stopSession(false); pitchHistory.clear(); samples.clear(); graph.clear(); livePitch.text = "— Hz"; livePitch.setTextColor(purple)
        feedback.text = "Waiting for voice…"; feedback.setTextColor(muted); scoreView.text = "Consistency\n—"; timerView.text = "Session: 00:00"
        statusView.text = "Microphone ready • Tap Start"
    }

    private fun playReferenceTone() {
        targetHz = targetInput.text.toString().toDoubleOrNull()?.coerceIn(60.0, 400.0) ?: 136.0
        targetInput.setText(fmt(targetHz)); refreshModeButtons()
        Thread {
            try {
                referenceTrack?.release()
                val duration = 1600
                val count = sampleRate * duration / 1000
                val buffer = ShortArray(1024)
                val minTrackBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minTrackBuffer <= 0) throw IllegalStateException("Audio output unavailable")
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                    .setBufferSizeInBytes(max(minTrackBuffer, buffer.size * 2 * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (track.state != AudioTrack.STATE_INITIALIZED) {
                    track.release()
                    throw IllegalStateException("Audio output could not be initialized")
                }
                referenceTrack = track
                track.setVolume(1.0f)
                track.play()
                var index = 0
                while (index < count && referenceTrack == track) {
                    val n = min(buffer.size, count - index)
                    for (i in 0 until n) {
                        val t = (index + i).toDouble() / sampleRate
                        val fadeIn = min(1.0, t / 0.08)
                        val fadeOut = min(1.0, (duration / 1000.0 - t) / 0.12).coerceAtLeast(0.0)
                        buffer[i] = (sin(2.0 * Math.PI * targetHz * t) * 9000 * fadeIn * fadeOut).toInt().toShort()
                    }
                    track.write(buffer, 0, n, AudioTrack.WRITE_BLOCKING)
                    index += n
                }
                track.stop(); track.release()
                referenceTrack = null
            } catch (_: Throwable) { handler.post { Toast.makeText(this, "Reference tone could not be played", Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun showResult() {
        trainerContainer.visibility = View.GONE; historyContainer.visibility = View.GONE; settingsContainer.visibility = View.GONE; resultContainer.visibility = View.VISIBLE
        resultContainer.removeAllViews()
        val metrics = finalMetrics()
        resultContainer.addView(text("Session Complete", 27f, purpleDark, Gravity.CENTER), lp().apply { bottomMargin = dp(8) })
        resultContainer.addView(text(if (metrics.score >= 85) "🏆 Great chanting!" else if (metrics.score >= 70) "✨ Good practice" else "🌱 Keep practising", 22f, purple, Gravity.CENTER), lp().apply { bottomMargin = dp(12) })
        resultContainer.addView(scoreCard(metrics), cardLp())
        if (mode == ChantMode.PHRASE) resultContainer.addView(phraseAnalysis(), cardLp())
        val save = button("💾 Save Session", true)
        val again = button("↻ Practice Again")
        resultContainer.addView(save, lp().apply { setMargins(dp(12), dp(10), dp(12), dp(6)) })
        resultContainer.addView(again, lp().apply { setMargins(dp(12), dp(4), dp(12), dp(6)) })
        save.setOnClickListener { saveHistory(metrics); save.isEnabled = false; save.text = "✓ Session Saved" }
        again.setOnClickListener { showTab(0); resetSession() }
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun scoreCard(m: Metrics): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, Color.rgb(235,229,240), dp(20), 1); setPadding(dp(18), dp(18), dp(18), dp(18))
        addView(text(String.format(Locale.US, "Overall Score\n%.0f%%", m.score), 28f, if (m.score >= 85) green else if (m.score >= 70) yellow else red, Gravity.CENTER))
        addView(text(String.format(Locale.US, "Pitch Accuracy  %.0f%%     Stability  %.0f%%     Consistency  %.0f%%", m.accuracy, m.stability, m.score), 13f, muted, Gravity.CENTER).apply { setPadding(0, dp(12), 0, 0) })
        addView(text(String.format(Locale.US, "Target %s Hz  •  Average %s Hz  •  Duration %02d:%02d", fmt(targetHz), fmt(m.average), sessionSeconds / 60, sessionSeconds % 60), 13f, muted, Gravity.CENTER).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun phraseAnalysis(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, Color.rgb(235,229,240), dp(20), 1); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        box.addView(text("ॐ नमः शिवाय — phrase analysis", 18f, purpleDark), lp().apply { bottomMargin = dp(4) })
        box.addView(text("Approximate first-pass segmentation from voiced portions.", 11f, muted), lp().apply { bottomMargin = dp(8) })
        val segments = findSegments().take(3)
        val labels = listOf("ॐ", "नमः", "शिवाय")
        labels.forEachIndexed { i, label ->
            val seg = segments.getOrNull(i)
            val v = seg?.map { it.pitch } ?: emptyList()
            val avg = if (v.isEmpty()) 0.0 else v.average().toDouble()
            val acc = if (v.isEmpty()) 0.0 else (100 - v.map { abs(1200.0 * log2(it / targetHz)) }.average() / 3).coerceIn(0.0, 100.0)
            box.addView(text(if (v.isEmpty()) "$label   — not detected" else String.format(Locale.US, "$label   %.1f Hz   •   %.0f%% pitch match", avg, acc), 15f, if (v.isEmpty()) muted else purpleDark), lp().apply { bottomMargin = dp(7) })
        }
        return box
    }

    private fun findSegments(): List<List<VoiceSample>> {
        if (samples.isEmpty()) return emptyList()
        val result = ArrayList<MutableList<VoiceSample>>()
        var current = mutableListOf<VoiceSample>()
        var last = -1L
        for (s in samples) {
            if (last >= 0 && s.timeMs - last > 300 && current.isNotEmpty()) { result.add(current); current = mutableListOf() }
            current.add(s); last = s.timeMs
        }
        if (current.isNotEmpty()) result.add(current)
        return result.sortedByDescending { it.size }
    }

    private fun finalMetrics(): Metrics {
        val vals = samples.map { it.pitch.toDouble() }
        if (vals.isEmpty()) return Metrics(0.0, 0.0, 0.0, 0.0, targetHz)
        val avg = vals.average(); val sd = sqrt(vals.map { (it - avg) * (it - avg) }.average())
        val accuracy = (100.0 - vals.map { abs(1200.0 * log2(it / targetHz)) }.average() / 3.0).coerceIn(0.0, 100.0)
        val stability = (100.0 - sd / targetHz * 500.0).coerceIn(0.0, 100.0)
        val score = (accuracy * 0.55 + stability * 0.45).coerceIn(0.0, 100.0)
        return Metrics(score, accuracy, stability, score, avg)
    }

    private fun saveHistory(m: Metrics) {
        val date = SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date())
        val entry = "${System.currentTimeMillis()}~$date~${fmt(targetHz)}~${if (mode == ChantMode.OM) "ॐ" else "ॐ नमः शिवाय"}~${m.score.toInt()}"
        val set = prefs.getStringSet("history", emptySet())?.toMutableSet() ?: mutableSetOf()
        set.add(entry); while (set.size > 20) set.remove(set.minByOrNull { it.substringBefore("~").toLongOrNull() ?: 0L } ?: entry)
        prefs.edit().putStringSet("history", set).apply()
    }

    private fun fmt(v: Double): String = if (abs(v - v.toInt()) < 0.05) v.toInt().toString() else String.format(Locale.US, "%.1f", v)

    override fun onBackPressed() {
        if (resultContainer.visibility == View.VISIBLE) { showTab(0); return }
        super.onBackPressed()
    }

    override fun onDestroy() {
        stopSession(false)
        try { referenceTrack?.stop() } catch (_: Throwable) {}
        try { referenceTrack?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }

    data class VoiceSample(val timeMs: Long, val pitch: Float)
    data class Metrics(val score: Double, val accuracy: Double, val stability: Double, val consistency: Double, val average: Double)
    enum class ChantMode { OM, PHRASE }

    class PitchGraphView(context: Context, private val lineColor: Int) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val values = ArrayDeque<Float>()
        private var target = 136f
        fun setTarget(t: Float) { target = t; invalidate() }
        fun addPitch(v: Float) { values.addLast(v); while (values.size > 120) values.removeFirst(); invalidate() }
        fun clear() { values.clear(); invalidate() }
        override fun onDraw(c: Canvas) {
            super.onDraw(c); val w = width.toFloat(); val h = height.toFloat()
            paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawRoundRect(0f,0f,w,h,22f,22f,paint)
            val minHz = max(60f, target - 50); val maxHz = target + 50
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(190,176,202)
            val y = h - ((target-minHz)/(maxHz-minHz))*h; c.drawLine(0f,y,w,y,paint)
            if (values.size < 2) return
            val list = values.toList(); val path = Path()
            for (i in list.indices) { val x=i.toFloat()/(list.size-1)*w; val n=((list[i]-minHz)/(maxHz-minHz)).coerceIn(0f,1f); val py=h-n*h; if(i==0)path.moveTo(x,py) else path.lineTo(x,py) }
            paint.color=lineColor; paint.strokeWidth=dpStroke(); c.drawPath(path,paint)
            paint.style=Paint.Style.FILL; paint.color=Color.rgb(125,106,145); paint.textSize=14f; c.drawText(String.format(Locale.US,"Target %.0f Hz",target), dp(10).toFloat(), dp(22).toFloat(), paint)
        }
        private fun dp(v:Int)= (v*resources.displayMetrics.density+0.5f).toInt()
        private fun dpStroke()=(4*resources.displayMetrics.density+0.5f)
    }

    object PitchDetector {
        fun detect(samples: ShortArray, n: Int, sampleRate: Int): PitchResult? {
            var energy=0.0
            for(i in 0 until n){val x=samples[i]/32768.0;energy+=x*x}
            val rms=sqrt(energy/n); if(rms<0.012)return null
            val minLag=sampleRate/400; val maxLag=min(sampleRate/60,n-2)
            var bestLag=-1; var best=0.0
            for(lag in minLag..maxLag){
                var sum=0.0;var e1=0.0;var e2=0.0;val limit=n-lag
                for(i in 0 until limit){val x=samples[i]/32768.0;val y=samples[i+lag]/32768.0;sum+=x*y;e1+=x*x;e2+=y*y}
                val d=sqrt(e1*e2); if(d>0){val corr=sum/d;if(corr>best){best=corr;bestLag=lag}}
            }
            if(bestLag<=0||best<0.55)return null
            var lag=bestLag.toDouble()
            if(bestLag>minLag&&bestLag<maxLag){
                fun corr(l:Int):Double{var s=0.0;var e1=0.0;var e2=0.0;val lim=n-l;for(i in 0 until lim){val x=samples[i]/32768.0;val y=samples[i+l]/32768.0;s+=x*y;e1+=x*x;e2+=y*y};return if(e1*e2>0)s/sqrt(e1*e2) else 0.0}
                val a=corr(bestLag-1);val b=corr(bestLag);val d=corr(bestLag+1);val denom=(a-2*b+d);if(abs(denom)>1e-6)lag=bestLag+(0.5*(a-d)/denom)
            }
            return PitchResult(sampleRate/lag,best)
        }
    }
    data class PitchResult(val pitchHz:Double,val confidence:Double)
}

private fun ColorDrawableCompat(color: Int): android.graphics.drawable.ColorDrawable = android.graphics.drawable.ColorDrawable(color)
