# Om Pitch Trainer — Chanting Coach v4.2.0

Android practice coach for `ॐ` and `ॐ नमः शिवाय`.

## Features
- Touch-friendly trainer, history, settings, and session-complete screens.
- Select `ॐ` or `ॐ नमः शिवाय`; adjustable 60–400 Hz target with +/- controls.
- Separate **Slow Chant Guide** and **Pitch Tone** controls. The guide uses slower Hindi text-to-speech, lower voice pitch, elongated vowel spelling, pauses, and repeated mantra phrasing to sound more like paced recitation than conversational speech. Pitch Tone remains a pure tone at the selected Hz.
- YIN-based fundamental-frequency detection with DC removal, RMS gate, cumulative mean normalized difference, confidence threshold, and parabolic lag interpolation.
- Pitch smoothing, octave correction/rejection, green/yellow/red cents feedback, live graph, timer, accuracy/stability/consistency score from 0–100.
- Records microphone PCM during the session, saves a WAV locally when Stop is pressed, and provides replay from the result screen and Trainer screen. History can replay saved session audio.
- Local practice history (up to 20 entries), settings, and a reset-practice control.
- For `ॐ नमः शिवाय`, the app displays clearly labelled approximate voiced-segment pitch information. It does not claim exact syllable boundaries without speech/phoneme recognition.

## Important limitations
- A selected 136 Hz pitch is a user-chosen training target, not a universally correct frequency for a mantra.
- The Slow Chant Guide is still synthesized speech; Android TTS cannot produce a reliable sung melody and the exact voice depends on the installed engine. An authentic human devotional chant requires a licensed/owned recording to be added as an audio asset.
- Pitch scores are training estimates, not spiritual correctness scores.
- Audio is stored locally in the app's private storage. Clearing app data/uninstalling removes those recordings.

## Build
Use the repository's GitHub Actions workflow. The ZIP must be named `OmPitchTrainer-Android-MVP.zip` and the workflow should extract it into the expected directory. This environment does not include the Android SDK, so final Android compilation must be confirmed by GitHub Actions.
