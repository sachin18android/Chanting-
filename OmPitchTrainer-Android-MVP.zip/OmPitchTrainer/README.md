# Om Pitch Trainer — Chanting Coach v3.1

An Android pitch-consistency trainer for `ॐ` and `ॐ नमः शिवाय`.

## v3.1 features
- Polished interactive trainer UI with proper Android dp sizing.
- `ॐ` and `ॐ नमः शिवाय` practice modes.
- Editable target pitch with +/- controls.
- Working reference tone generated locally through Android AudioTrack at a fixed 44.1 kHz sample rate, with output-buffer/state checks.
- Real-time pitch in Hz and green/yellow/red feedback based on cents from target.
- Smoothed pitch graph with octave-jump rejection and confidence gating.
- 0–100 consistency score, pitch accuracy and stability.
- Session timer and completion screen.
- Persistent practice history using SharedPreferences.
- Settings screen with target and microphone status.
- For `ॐ नमः शिवाय`, approximate first-pass analysis of `ॐ`, `नमः`, and `शिवाय` from voiced segments.

## Important
The app measures how consistently a user stays near a chosen target pitch. It does not claim that a particular Hz value is the universally correct frequency of a mantra.

The phrase-part analysis is intentionally labeled approximate: robust automatic Sanskrit syllable recognition would require a separate speech/phoneme recognition layer and is not inferred solely from pitch.


## Build notes
- Version 3.1 fixes the previous compile failure caused by an undefined `sampleRate` and an Android `Canvas.drawText` integer/float mismatch.
- The reference-tone path validates the output buffer and `AudioTrack` state before playback.
