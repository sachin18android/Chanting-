# Om Pitch Trainer — Android MVP

This is a dependency-light Android MVP for real-time Om (`ॐ`) pitch training.

## What it does

- Requests microphone permission.
- Captures mono PCM audio from the phone microphone.
- Estimates fundamental pitch using normalized autocorrelation.
- Displays live pitch in Hz.
- Lets the user set a target pitch (default: 136 Hz).
- Shows deviation in cents and percentage.
- Plots a live pitch trace against the target.
- Calculates a simple pitch consistency score.
- Runs entirely on-device.

## Important

The app deliberately does NOT claim that 136 Hz is universally the "correct" frequency for Om.
It is a configurable reference pitch.

The current pitch detector is intentionally simple for an MVP. For a production app, improve it with:
- YIN or McLeod Pitch Method (MPM)
- harmonic correction / octave-error rejection
- adaptive noise gate
- median/EMA smoothing
- voiced/unvoiced detection
- phone microphone calibration
- session recording and history
- mantra syllable segmentation
- reference-chant comparison
- optional tanpura/drone reference

## Build

Open this folder in Android Studio.

Requirements:
- Android Studio with JDK 17
- Android SDK 35
- Gradle sync enabled

Then run on a physical Android phone. A physical phone is strongly preferred for microphone testing.

## Next milestone

Add:
1. Om + Om Namah Shivaya modes
2. chant repetition counter
3. pitch stability score
4. reference recording
5. pitch-contour similarity
6. session history
7. Hindi/Sanskrit UI
