# Om Pitch Trainer — Chanting Coach v3.0

An Android pitch-consistency trainer for `ॐ` and `ॐ नमः शिवाय`.

## v3 features
- Polished interactive trainer UI with proper Android dp sizing.
- `ॐ` and `ॐ नमः शिवाय` practice modes.
- Editable target pitch with +/- controls.
- Working reference tone generated locally through Android AudioTrack.
- Real-time pitch in Hz and green/yellow/red feedback based on cents from target.
- Smoothed pitch graph with octave-jump rejection and confidence gating.
- 0–100 consistency score, pitch accuracy and stability.
- Session timer and completion screen.
- Persistent practice history using SharedPreferences.
- Settings screen with target and microphone status.
- For `ॐ नमः शिवाय`, approximate first-pass analysis of `ॐ`, `नमः`, and `शिवाय` from voiced segments.

## Important
The app measures how consistently a user stays near a chosen target pitch. It does not claim that a particular Hz value is the universally correct frequency of a mantra.

The phrase-part analysis is intentionally labeled approximate: robust automatic Sanskrit syllable recognition would require a separate speech/phoneme recognition layer and is not inferred solely from pitch.
